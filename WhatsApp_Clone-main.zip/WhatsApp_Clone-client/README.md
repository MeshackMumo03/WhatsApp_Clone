Client Side code
