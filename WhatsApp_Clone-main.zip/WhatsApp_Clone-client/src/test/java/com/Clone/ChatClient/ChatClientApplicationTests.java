package com.Clone.ChatClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
